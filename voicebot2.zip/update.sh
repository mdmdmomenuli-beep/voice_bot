#!/bin/bash
# সার্ভারে কোড আপডেট: bash update.sh
cd "$(dirname "$0")"
git pull && ./venv/bin/pip install -r requirements.txt -q && systemctl restart voicebot && echo "আপডেট হয়েছে ✅"
