#!/bin/bash
# বট ব্যাকগ্রাউন্ডে চালু: bash run.sh
cd "$(dirname "$0")"
termux-wake-lock 2>/dev/null
tmux kill-session -t bot 2>/dev/null
tmux new-session -d -s bot "python bot_v2.py 2>&1 | tee bot.log"
echo "বট চালু হয়েছে ✅  লগ দেখতে: tmux attach -t bot"
