#!/bin/bash
tmux kill-session -t bot 2>/dev/null && echo "বট বন্ধ হয়েছে"
