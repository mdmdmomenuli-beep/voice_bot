#!/bin/bash
# সার্ভারে (Ubuntu) চালান: bash setup.sh
set -e
cd "$(dirname "$0")"
apt update && apt install -y python3 python3-pip python3-venv ffmpeg git
python3 -m venv venv
./venv/bin/pip install -r requirements.txt
if [ ! -f config.env ]; then
  cp config.env.example config.env
  echo "nano config.env দিয়ে key বসিয়ে আবার bash setup.sh চালান।"
  exit 0
fi
sed "s|/root/voicebot|$(pwd)|g" voicebot.service > /etc/systemd/system/voicebot.service
systemctl daemon-reload
systemctl enable --now voicebot
echo "বট চালু হয়েছে। দেখতে: systemctl status voicebot"
