#!/bin/bash
# Termux-এ একবার চালান: bash install_termux.sh
set -e
cd "$(dirname "$0")"
export DEBIAN_FRONTEND=noninteractive
pkg update -y -o Dpkg::Options::=--force-confold </dev/null
pkg upgrade -y -o Dpkg::Options::=--force-confold </dev/null
pkg install -y python ffmpeg tmux termux-api nano </dev/null
pip install --upgrade pip
pip install -r requirements.txt
if [ ! -f config.env ]; then
  cp config.env.example config.env
  echo "config.env বানানো হয়েছে। এখন এটা খুলে key বসান: nano config.env"
  echo "বসানোর পর আবার bash install_termux.sh চালান।"
  exit 0
fi
python -m py_compile bot_v2.py && echo "কোড ঠিক আছে ✅"
echo "বট চালু করতে: bash run.sh"
